package main;

import database.Database;
import fileread.fileRead;
import filewrite.fileWrite;
import keyboardinput.keyboardInput;
import movie.Movie;

import java.util.ArrayList;

import commands.Commands;

public class Main {
  public static void main(String[] args) {
    System.out.println("The TekTristan Movie Database");
    System.out.println("=============================");

    // Create a new file reader to read from the file "db.txt"
    fileRead fr = new fileRead("db.txt");
    ArrayList < String > lines = new ArrayList < > ();

    // Read each line from the file and add it to the lines list
    for (int i = 0; i < fr.getNumberOfLines(); i++) {
      String line = fr.getLine(i);
      lines.add(line);
    }

    // Create a new Commands object and call its commands() method
    Commands ins = new Commands();
    ins.commands();

    // Create a new keyboardInput and fileWrite object
    keyboardInput kb = new keyboardInput();
    fileWrite fw = new fileWrite("db.txt");

    // Write each line from the lines list to the file
    for (String fileWrite: lines) {
      fw.writeLine(fileWrite);
    }

    Database db = new Database("db.txt");
    String command = ""; {

      while (!command.equals("quit")) {
        System.out.println("=============================");
        command = kb.getKeyboardLine("Enter Command: ");

        switch (command) {
        case "new entry":
          String title = kb.getKeyboardLine("Enter title: ");
          if (title.length() >= 3) {
            int year = Integer.parseInt(kb.getKeyboardLine("Enter year: "));
            String dir = kb.getKeyboardLine("Enter director: ");
            String act1 = kb.getKeyboardLine("Enter actor 1: ");
            String act2 = kb.getKeyboardLine("Enter actor 2: ");

            int runtime = Integer.parseInt(kb.getKeyboardLine("Enter runtime in minutes: "));

            fw.writeLine(title + "*" + year + "*" + dir + "*" + act1 + "*" + act2 + "*" + runtime);
            Movie mov = new Movie(title, act2, dir, act1, year, runtime);
            db.addEntry(mov);
          }
          break;
        case "total lines":
          System.out.println(fr.getNumberOfLines() + " total lines in file");
          break;
        case "search by year":
          int searchYear = Integer.parseInt(kb.getKeyboardLine("Enter year: "));
          db.searchByYear(searchYear);
          break;
        case "search by actor":
          String searchActor = kb.getKeyboardLine("Enter actor: ");
          db.searchByActor(searchActor);
          break;
        case "search by runtime":
          int searchRun = Integer.parseInt(kb.getKeyboardLine("Enter runtime (in minutes): "));
          db.searchByRuntime(searchRun);
          break;
        case "search by director":
          String searchDir = kb.getKeyboardLine("Enter director: ");
          db.searchByDirector(searchDir);
          break;
        case "search by title":
          String searchTitle = kb.getKeyboardLine("Enter title: ");
          db.searchByTitle(searchTitle);
          break;
        }
      }

      fw.saveFile();
      kb.closeKeyboard();
    }

  }
}         
                



		
package commands;

public class Commands {

  public void commands() {
    String[] commands = new String[] {
      "new entry",
      "total lines",
      "search by actor",
      "search by year",
      "search by runtime",
      "search by director",
      "search by title",
      "quit"
    };
    System.out.println("Current Commands: ");
    for (String command: commands) {
      System.out.println(command);
    }
  }
}

package fileread;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class fileRead {

  // Fields
  private final ArrayList < String > lines;

  // Constructor
  public fileRead(String filename) {
    lines = new ArrayList < > ();
    try (BufferedReader bufferedReader = new BufferedReader(new FileReader(filename))) {
      String readLine;
      while ((readLine = bufferedReader.readLine()) != null) {
        lines.add(readLine);
      }
    } catch (IOException error) {
      error.printStackTrace();
    }
  }

  // Methods
  public int getNumberOfLines() {
    return lines.size();
  }

  public String getLine(int index) {
    return lines.get(index);
  }
}


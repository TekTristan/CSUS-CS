package keyboardinput;

import java.util.Scanner;

public class keyboardInput {

  // Fields
  private final Scanner scanner;

  // Constructor
  public keyboardInput() {
    scanner = new Scanner(System.in);
  }

  
  public String getKeyboardLine(String prompt) {
	System.out.println(prompt);
	return scanner.nextLine().toLowerCase();
  }


  public void closeKeyboard() {
    scanner.close();
  }
}

package database;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import fileread.fileRead;
import movie.Movie;

public class Database {
  // Fields
  private List < Movie > movies;

  // Constructor
  public Database(String filename) {
    movies = new ArrayList < > ();
    fileRead fr = new fileRead(filename);
    for (int i = 0; i < fr.getNumberOfLines(); i++) {
      String raw = fr.getLine(i);

      StringTokenizer st = new StringTokenizer(raw, "*");
      while (st.hasMoreTokens()) {
        String title = st.nextToken();
        int year = Integer.parseInt(st.nextToken());
        String director = st.nextToken();
        String actor1 = st.nextToken();
        String actor2 = st.nextToken();
        int runtime = Integer.parseInt(st.nextToken());
        Movie m = new Movie(title, actor1, actor2, director, year, runtime);
        movies.add(m);
      }
    }
  }

  // Methods
  public void addEntry(Movie newEntry) {
    movies.add(newEntry);
  }

  public void searchByTitle(String title) {
    boolean a = false;
    int i = 0;
    while (!a && i < movies.size()) {
      Movie movie = movies.get(i);
      if (title.equalsIgnoreCase(movie.getTitle())) {
        a = true;
        System.out.println("Actors: " + movie.getActor1() + ", " + movie.getActor2());
        System.out.println("Year: " + movie.getYear());
        System.out.println("Director: " + movie.getDirector());
        System.out.println("Runtime: " + movie.getRuntime());
      }
      i++;
    }
    if (!a) {
      System.out.println("Title not found... try again.");
    }
  }

  public void searchByActor(String actor) {
    boolean a = false;
    int i = 0;
    while (i < movies.size()) {
      Movie movie = movies.get(i);
      if (actor.equals(movie.getActor1()) || actor.equals(movie.getActor2())) {
        System.out.println("Actor has been in the movie(s): " + movie.getTitle());
        a = true;
      }
      i++;
    }

    if (!a) {
      System.out.println("Actor not found in any movie... try again ");
    }
  }

  public void searchByDirector(String director) {
    List < String > moviesByDirector = new ArrayList < > ();
    int i = 0;
    while (i < movies.size()) {
      Movie movie = movies.get(i);
      if (director.equals(movie.getDirector())) {
        moviesByDirector.add(movie.getTitle());
      }
      i++;
    }

    if (moviesByDirector.isEmpty()) {
      System.out.println("No movies with this director found... try again ");
    } else {
      System.out.println("Movie titles this director has been in: ");
      for (String movie: moviesByDirector) {
        System.out.println(movie);
      }
    }
  }

  public void searchByYear(int year) {
    boolean a = false;
    int i = 0;
    while (i < movies.size()) {
      Movie movie = movies.get(i);
      if (year == movie.getYear()) {
        System.out.println("Movie titles released this year are: " + movie.getTitle());
        a = true;
      }
      i++;
    }
    if (a == false) {
      System.out.println("No movies released in that year... try again ");
    }
  }

  public void searchByRuntime(int runtime) {
    boolean a = false;
    int i = 0;
    while (i < movies.size()) {
      Movie movie = movies.get(i);
      if (runtime == movie.getRuntime()) {
        System.out.println("Movie titles with this runtime are: " + movie.getTitle());
        a = true;
      }
      i++;
    }
    if (a == false) {
      System.out.println("No movies with this runtime found... try again ");
    }
  }
}


